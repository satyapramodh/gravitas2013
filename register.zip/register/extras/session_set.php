<?php
	if(!isset($_SESSION['conti'])||!isset($_SESSION['college_name']))
	{
		header("location:index.php");
	}
	
	
?>