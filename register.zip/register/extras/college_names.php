<?php
echo "<option>IIT Madras</option>";
echo "<option>VIT Chennai</option>";
echo "<option>Manipal University</option>";
echo "<option>Anna University</option>";
echo "<option>SRM University</option>";
echo "<option>Shastra University</option>";
echo "<option>Amrita University</option>";
echo "<option>NIT Trichy</option>";
echo "<option>NIT Warangal</option>";
echo "<option>NIT Suratkal</option>";

?>