<?php
mysql_connect("localhost","vitgravi_tech13","aricore13") or die(mysql_error());
mysql_select_db("vitgravi_online_reg");
?>